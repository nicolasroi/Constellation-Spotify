﻿from __future__ import unicode_literals
import sys
import threading
import Constellation
import spotify
import VolumeControl_lib as vc

# Global variables declared in the script
global track
track = None
global track_index

def onStart():

    Constellation.PushStateObject("Spotify_isPlaying", False)
    Constellation.PushStateObject("track_Title", "")

    # Assuming a spotify_appkey.key in the Scripts directory. That specific file can also be found here => 
    session = spotify.Session()
    
    # Process events in the background
    loop = spotify.EventLoop(session)
    loop.start()

    # Connect an audio sink
    audio = spotify.AlsaSink(session)

    # Events for coordination
    logged_in = threading.Event()
    end_of_track = threading.Event()

    
    def on_connection_state_updated(session):
        if session.connection.state is spotify.ConnectionState.LOGGED_IN:
            logged_in.set()

    def on_end_of_track(self):
        end_of_track.set()   



    def play_pause(track_local):
        if session.player.state is spotify.PlayerState.UNLOADED:
            session.player.load(track_local)

        if (session.player.state is spotify.PlayerState.LOADED) or (session.player.state is spotify.PlayerState.PAUSED):
            session.player.play()
            Constellation.PushStateObject("Spotify_isPlaying", True)
            Constellation.WriteWarn("Spotify Playing")

        elif (session.player.state is spotify.PlayerState.PLAYING):
            session.player.play(False)
            Constellation.PushStateObject("Spotify_isPlaying", False)
            Constellation.WriteWarn("Spotify Paused")



    # Register event listeners
    session.on(spotify.SessionEvent.CONNECTION_STATE_UPDATED, on_connection_state_updated)
    session.on(spotify.SessionEvent.END_OF_TRACK, on_end_of_track)


    # Get account info(spotify account)
    if (Constellation.GetSetting("spotify_username") != None) and (Constellation.GetSetting("spotify_password") != None):
        pass
    else:
        Constellation.RequestSettings()
        Constellation.WriteError("Couldn't get username from settings! RTFM noob!")

    if Constellation.GetSetting("spotify_password") != None:
        pass
    else:
        Constellation.RequestSettings()
        Constellation.WriteError("Couldn't get password from settings! RTFM noob!")


    session.login(Constellation.GetSetting("spotify_username"),password=Constellation.GetSetting("spotify_password"))
    

    logged_in.wait()


    @Constellation.MessageCallback("MusicControl")
    def MusicControl(data):
        "Allow to control Spotify.  A valid playlist URI or a track URI must be specified."
        global track
        global track_index
        global playlist

        Constellation.WriteInfo('Instruction = ' + str(data.instruction))
    
        if (data.instruction == "PLAY_TRACK") :
            Constellation.WriteInfo("URI = " + str(data.uri))
            if track != None:
                session.player.unload()
                track = session.get_track(data.uri)
                play_pause(track)
                Constellation.PushStateObject("track_Title", track.name)
   
        elif (data.instruction == "PLAY_PLAYLIST"):
            Constellation.WriteInfo("URI = " + str(data.uri))
            playlist = session.get_playlist(data.uri)
            playlist.load()
            track_index = 0
            track = playlist.tracks[track_index]
            session.player.unload()
            play_pause(track)
            Constellation.PushStateObject("track_Title", track.name)

        elif (data.instruction == "NEXT_SONG") and (track_index <len(playlist.tracks)):
            track_index = track_index+1
            if playlist.tracks != []:
                track = playlist.tracks[track_index]
                session.player.unload()
                play_pause(track)
                Constellation.PushStateObject("track_Title", track.name)

        elif (data.instruction == "PREVIOUS_SONG") and (track_index > 0):
            track_index = track_index-1
            if playlist.tracks != []:
                track = playlist.tracks[track_index]
                session.player.unload()
                play_pause(track)
                Constellation.PushStateObject("track_Title", track.name)

        elif (data.instruction == "PLAY_PAUSE") and (track != None):            
            play_pause(track)
        elif data.instruction == "TURNUP_VOLUME":
            vc.IncreaseVolume()
        elif data.instruction == "TURNDOWN_VOLUME":
            vc.DecreaseVolume()
 
    Constellation.WriteWarn("Connected to Spotify on the %s account" % Constellation.GetSetting("spotify_username"))

Constellation.Start(onStart)