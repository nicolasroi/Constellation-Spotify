﻿from __future__ import unicode_literals

import sys
import threading
import Constellation
import alsaaudio


mixer = alsaaudio.Mixer(control = 'PCM') ## In this case, there is only one channel on the output. More info on multiple channel outputs on http://larsimmisch.github.io/pyalsaaudio/libalsaaudio.html#mixer-objects 

#   Increase volume by 5 on a scale from 0 to 100
def IncreaseVolume():
    if mixer.getmute()==1:
        mixer.setmute(0)
    if int(mixer.getvolume()[0])>=95:
        pass
    else:
        Constellation.WriteWarn("volume+ on rPi")
        return mixer.setvolume(int(mixer.getvolume()[0]+5))

#   Decrease volume by 5 on a scale from 0 to 100
def DecreaseVolume():
    if mixer.getmute()==1:
        mixer.setmute(0)
    if int(mixer.getvolume()[0])<=5:
        pass
    else:
        Constellation.WriteWarn("volume- on rPi")
        return mixer.setvolume(int(mixer.getvolume()[0]-5))